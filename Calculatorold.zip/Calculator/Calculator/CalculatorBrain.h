//
//  CalculatorBrain.h
//  Calculator
//
//  Created by mavriksc on 10/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CalculatorBrain : NSObject {
    double operand;
    NSString   *waitingOperation;
    NSMutableArray *expression;
    double waitingOperand;
    double  memoryValue;
    
    
}
- (void)setOperand:(double)aDouble;
- (double)performOperation:(NSString *)operation;   

@property (readonly) double waitingOperand;
@property (readonly) double memoryValue;
@property (readonly) id expression; 

+ (double)evaluateExpression:(id)anExpression usingVariableValues:(NSDictionary *)variables; 
+ (NSSet *)variablesInExpression:(id)anExpression;
+ (NSString *)descriptionOfExpression:(id)anExpression; 
+ (id)propertyListForExpression:(id)anExpression;
+ (id)expressionForPropertyList:(id)propertyList;

@end
