//
//  CalculatorViewController.m
//  Calculator
//
//  Created by mavriksc on 10/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CalculatorViewController.h"

@implementation CalculatorViewController
-(CalculatorBrain *)brain
{
    if (!brain) {
        brain=[[CalculatorBrain alloc] init];
    }
    return brain;
}

- (IBAction)digitPressed:(UIButton *)sender
{
   
    NSString *digit = [[sender titleLabel] text];
    /*
    if ([digit isEqual:@"."]) {
        if (!userIsInTheMiddleOfTypingADecimal) {
        
        [display setText:[[display text] stringByAppendingString:digit]];
            userIsInTheMiddleOfTypingADecimal = YES;
            userIsInTheMiddleOfTypingANumber =YES;
                                                 
        }        
    }
    else 
     
     */
    
    if (userIsInTheMiddleOfTypingANumber) {
        if ([digit isEqual:@"."]) {
        if (!userIsInTheMiddleOfTypingADecimal) {
            [display setText:[[display  text] stringByAppendingString:digit]];
            userIsInTheMiddleOfTypingADecimal = YES;
        }
        }else {
        
        [display setText:[[display  text] stringByAppendingString:digit]];
        }
    }
    else//new number
    {
        if ([digit isEqual:@"."]) {
            if (!userIsInTheMiddleOfTypingADecimal) {
                
                [display setText:@"0."];
                userIsInTheMiddleOfTypingADecimal = YES;
                userIsInTheMiddleOfTypingANumber = YES;
            }
        }else {
        [display setText:digit];
        userIsInTheMiddleOfTypingANumber  = YES;
        }
    }
}

- (IBAction)operationPressed:(UIButton *)sender
//need to turn off something when the single operand buttons are pressed to forget operand in some cases find out those cases.
// ^^^^^^ seems to be fixed but look here if there are future problems with single operand functions.
{
    if (userIsInTheMiddleOfTypingANumber) {
        [[self brain] setOperand:[[display text] doubleValue]];
        userIsInTheMiddleOfTypingANumber = NO;
        userIsInTheMiddleOfTypingADecimal = NO;
    }
    NSString *operation =[[sender titleLabel] text];
    
    double result = [[self brain] performOperation:operation];
    [display setText:[NSString  stringWithFormat:@"%g",result]];
    [mem setText:[NSString stringWithFormat:@"%g",[brain memoryValue]]];
    [waitingOperand setText:[NSString stringWithFormat:@"%g",[brain waitingOperand]]];
}

- (void)dealloc
{
    [brain release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
