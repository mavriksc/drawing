//
//  CalculatorTests.h
//  CalculatorTests
//
//  Created by mavriksc on 10/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface CalculatorTests : SenTestCase {
@private
    
}

@end
