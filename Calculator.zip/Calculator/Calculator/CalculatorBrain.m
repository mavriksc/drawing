//
//  CalculatorBrain.m
//  Calculator
//
//  Created by mavriksc on 10/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CalculatorBrain.h"


@implementation CalculatorBrain
@synthesize memoryValue,waitingOperand,expression;

- (void)setOperand:(double)aDouble
{
    operand= aDouble;
}
-(void) perfromWaitingOperation
{
    if ([@"+" isEqual:waitingOperation])
    {
        operand = waitingOperand+operand;
    }
    else if ([@"*" isEqual:waitingOperation])
    {
        operand = waitingOperand * operand;
    }
    else if ([@"-" isEqual:waitingOperation])
    {
        operand = waitingOperand - operand;
    }
    else if ([@"/" isEqual:waitingOperation])
    {
        if (operand) {
            operand = waitingOperand / operand;
        }
    }
    
}
- (double)performOperation:(NSString *)operation
{
    if ([operation isEqual:@"sqrt"])
    {
        if (operand >= 0)
        {
        operand = sqrt(operand);
        }
    }
    else if ([@"+/-" isEqual:operation])
    {
        operand = - operand;
        
    }
    else if([@"1/x" isEqual:operation])
    {
        if (operand) {
            operand = 1/operand;
        }
    }
    else if([@"cos" isEqual:operation])
    {
        operand =   cos(operand);
    }
    else if([@"sin" isEqual:operation])
    {
        operand = sin(operand);
    }
    else if([@"Store" isEqual:operation])
    {
        memoryValue = operand;
    }
    else if ([@"Recall" isEqual:operation])
    {
        operand = memoryValue;
    }
    else if ([@"MEM+" isEqual:operation])
    {
        memoryValue +=operand;
    }
    else if ([@"C" isEqual:operation])
    {
        operand = 0;
        memoryValue = 0;
        waitingOperand = 0;
        waitingOperation = nil;
    }
    else
    {
        [self perfromWaitingOperation];
        waitingOperation = operation;
        waitingOperand = operand;
    }
    return operand;

}  

+ (double)evaluateExpression:(id)anExpression usingVariableValues:(NSDictionary *)variables
{
    return (0);//remove when implementing 
}
+ (NSSet *)variablesInExpression:(id)anExpression
{
    return nil;//remove when implementing 

}

+ (NSString *)descriptionOfExpression:(id)anExpression
{
    return nil;//remove when implementing 

}
 
+ (id)propertyListForExpression:(id)anExpression
{
    return nil;//remove when implementing 

}

+ (id)expressionForPropertyList:(id)propertyList
{
    return nil;//remove when implementing 

}


@end
